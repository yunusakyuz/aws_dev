# AWS & DevOps Teamwork Agendas

List of teamwork agendas for AWS & DevOps learning path as follows;
List of teamwork agendas for AWS & DevOps learning path as follows;

- [Teamwork Agenda - 001 : AWS EC2, SG, CF, Linux, GIT](./eu-tw-001-student.pdf)