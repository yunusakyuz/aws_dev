# Linux Hands-on Trainings

List of hands-on trainings within Linux workshop as follows;