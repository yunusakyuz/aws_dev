# AWS Projects

List of projects within AWS workshop as follows;


