# AWS Workshop

AWS Workshop contains hands-on trainings and projects.

- [List of AWS Hands-on Trainings](./hands-on/README.md)

- [List of AWS Projects](./projects/README.md)

- [AWS Session Class-notes](./class-notes/README.md)