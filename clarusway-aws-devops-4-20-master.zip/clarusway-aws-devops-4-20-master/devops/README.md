# DevOps Workshop

DevOps Workshop contains hands-on trainings and projects.

- [List of DevOps Hands-on Trainings](./hands-on/README.md)

- [List of DevOps Projects](./projects/README.md)

- [DevOps Session Class-notes](./class-notes/README.md)