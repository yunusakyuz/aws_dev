# DevOps Hands-on Trainings

List of hands-on trainings within AWS workshop as follows;