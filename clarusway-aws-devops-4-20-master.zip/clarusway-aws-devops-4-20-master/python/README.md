# Python Workshop

Python Workshop contains hands-on trainings and projects.

- [List of Python Hands-on Trainings](./hands-on/README.md)

- [List of Python Projects](./projects/README.md)

- [Python Workshop Coding Challenges](./coding-challenges/README.md)

- [Python Session Class-notes](./class-notes/README.md)