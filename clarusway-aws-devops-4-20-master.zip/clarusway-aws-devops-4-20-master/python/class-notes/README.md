# Python Session Class-notes

