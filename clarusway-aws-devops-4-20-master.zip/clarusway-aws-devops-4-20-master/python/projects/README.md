# Python Projects

List of projects within Python workshop as follows;